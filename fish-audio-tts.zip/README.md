# Fish Audio 文字转语音插件

> 适用于 WAuxiliary 框架的 TTS 插件，基于 Fish Audio API

## 使用方法

- 输入 **"转语音"** 打开转换面板
- 输入 **"设置key"** 配置 API Key（支持回车保存）
- 输入 **"设置音色"** 浏览并选择音色
  - 顶部搜索栏实时过滤
  - 点击黑色 **"使用"** 按钮选择 → 变白底 **"当前"**
  - 点击蓝色 **"试听"** 按钮预览
- 输入 **"音色列表"** 查看全部可用音色
- 日志输出到 `fish_tts.log`

## 安装

1. 确保已安装 WAuxiliary 框架
2. 将 `FishAudioTTS.java` 和 `config.prop` 放入插件目录
3. 在 WAuxiliary 中启用插件
4. 首次使用前输入 **"设置key"** 配置 Fish Audio API Key

## 获取 API Key

前往 [Fish Audio API Keys](https://fish.audio/app/api-keys/) 创建密钥

## 配置

- `config.prop` — 插件配置文件，存储 API Key 和当前音色
- 所有配置也可通过插件内置面板修改

## 版本

- 当前版本: 1.0
- 作者: 小米线
- API: Fish Audio (API 不免费)
